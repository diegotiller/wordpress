<?php get_header(); ?>

<section>

	<div class="container">
		<div class="row">
			<div class="col-sm-8 maincontent">
				...
			</div>
			<?php get_sidebar(); ?>
		</div>
	</div>

</section>

<?php get_footer(); ?>