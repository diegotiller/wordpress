jQuery(function(){
	jQuery('.mainfooter_scroll').on('click', function(){
		jQuery(document.body).scrollTop(0);
	});
});